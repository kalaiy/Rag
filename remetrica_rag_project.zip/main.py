from retriever import model
import faiss

def query_index(user_query):
    index = faiss.read_index("embeddings/faiss.index")
    with open("embeddings/corpus.txt") as f:
        docs = f.readlines()
    emb = model.encode([user_query])
    D, I = index.search(emb, k=5)
    return [docs[i].strip() for i in I[0]]

def build_prompt(user_query, context_lines):
    context = "\n".join(context_lines)
    return f"""
# DLL API Reference:
{context}

# User Instruction:
{user_query}

# Task:
Generate Python code using the Remetrica DLL API to fulfill the user's request.
"""

def run_mistral(prompt):
    import subprocess
    proc = subprocess.Popen(["ollama", "run", "mistral"],
                            stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE)
    out, _ = proc.communicate(prompt.encode())
    return out.decode()

if __name__ == "__main__":
    query = "Create 5 LossModels and link to LossDisplay1"
    context = query_index(query)
    prompt = build_prompt(query, context)
    generated_code = run_mistral(prompt)
    print("Generated Code:\n", generated_code)
    input("Run the code? (Y to continue): ")
    from executor import execute_api_calls
    execute_api_calls(generated_code)
