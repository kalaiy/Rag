from sentence_transformers import SentenceTransformer
import faiss
import os, re

model = SentenceTransformer('all-MiniLM-L6-v2')
doc_path = 'data/dll_docs.html'

def clean_html(text):
    return re.sub('<[^<]+?>', '', text)

def load_chunks(path):
    with open(path, 'r') as f:
        raw = f.read()
    text = clean_html(raw)
    lines = [line.strip() for line in text.splitlines() if len(line.strip()) > 20]
    return lines

def create_faiss_index(docs):
    embeddings = model.encode(docs)
    index = faiss.IndexFlatL2(384)
    index.add(embeddings)
    return index, embeddings

if __name__ == "__main__":
    docs = load_chunks(doc_path)
    index, _ = create_faiss_index(docs)
    faiss.write_index(index, "embeddings/faiss.index")
    with open("embeddings/corpus.txt", "w") as f:
        for line in docs:
            f.write(line + "\n")
