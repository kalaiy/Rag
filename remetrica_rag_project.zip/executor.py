import clr
clr.AddReference("path/to/RemetricaAPI.dll")
from RemetricaNamespace import RemetricaApp

def execute_api_calls(script: str):
    exec(script, globals())
